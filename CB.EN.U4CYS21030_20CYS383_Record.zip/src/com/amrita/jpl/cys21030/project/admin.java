package com.amrita.jpl.cys21030.project;
package account;

public  interface admin {
static final String  uname ="kollepalli";
static final String pass = "rshith";
public void view_acc_details(user u);
public void view_transactions();
public void view_withdrawals();
public void view_deposits();


}
