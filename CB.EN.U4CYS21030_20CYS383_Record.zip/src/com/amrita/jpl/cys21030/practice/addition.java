package com.amrita.jpl.21030.practice;

public class addition {

        public static void main(String args[])
        {
            int n1 = 300, n2 = 140, sum;
            sum = n1 + n2;
            System.out.println("The sum of numbers is: "+sum);
        }
    }