
package com.amrita.jpl.21030.practice;

public class subtraction {

    public static void main(String[] args) {


        int x=30;
        int y=14;


        int subtract;

        subtract = x - y;


        System.out.println("The substraction of two Numbers: " + subtract);

    }

}